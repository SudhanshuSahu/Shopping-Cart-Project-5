const express = require('express')
const router = express.Router()
const {createUser, loginUser, getUserProfile,updateUser} = require("../controllers/userController")
const {authentication} = require("../middleware/auth") 

router.post("/register",createUser)

router.post("/login", loginUser)

router.get("/user/:userId/profile",authentication, getUserProfile)
router.post("/update/:userId",updateUser)




module.exports =router